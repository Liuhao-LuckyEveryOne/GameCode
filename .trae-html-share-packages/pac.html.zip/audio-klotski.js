'use strict';
/**
 * 华容道音效分册（audio-klotski.js）—— v3.5（20261118）自 audio.js 游戏专属音效区拆出
 * 依赖 audio.js（合成引擎与 _tone/_noise/_arpeggio 原语），须在其后、业务 js 之前加载；
 * 挂载方式：Object.assign(SFX, {...})；原语经 SFX._tone / SFX._noise / SFX._arpeggio
 * 内部约定键取用（仅面向分册，业务代码禁止调用下划线键）
 */
(() => {
    // 防御性降级：audio.js 未加载（脚本顺序错误/加载失败）时 SFX 与合成原语可能缺失，
    // 引擎缺失整体跳过注册、原语以空函数兜底，保证本分册加载与音效调用不抛错中断游戏逻辑
    const noop = () => {};
    if (typeof SFX === 'undefined' || SFX === null) return;
    const pickPrimitive = (key) => (typeof SFX[key] === 'function' ? SFX[key] : noop);
    const tone = pickPrimitive('_tone');
    const noise = pickPrimitive('_noise');
    const arpeggio = pickPrimitive('_arpeggio');
    Object.assign(SFX, {
        /* ---------- 华容道音效 ---------- */
        /** 滑块滑动：低沉木质滑音，音高随一次滑过格数递增（连滑越远音越高昂） */
        klMove: (steps = 1) => { const f = 240 + (Math.max(1, steps) - 1) * 60; tone(f, 0.07, 'triangle', 0.12, f * 0.7); },
        /** 落位吸附：短促"咔哒" + 轻噪声，滑动补间结束棋子吸进格位的质感 */
        klSnap: () => { tone(340, 0.04, 'square', 0.09); noise(0.03, 0.04, 900); },
        /** 临近出口：轻快上行双哔（曹操一步即可入出口、临门高亮点燃的提示） */
        klNear: () => { tone(880, 0.06, 'square', 0.08); tone(1175, 0.09, 'square', 0.08, 0, 0.09); },
        /** 回弹：低到高快速上滑"啵嘤"弹性音（拖拽未过半格归位） */
        klBounce: () => tone(150, 0.1, 'triangle', 0.1, 270),
        /** 新纪录：高音区五连琶音延迟起奏，与通关琶音接力形成"通关 → 破纪录"两段式辉煌 */
        klRecord: () => [784, 988, 1319, 1760, 2093].forEach((f, i) => tone(f, 0.1, 'triangle', 0.11, 0, 0.55 + i * 0.09)),
        /** 选中滑块：轻点确认音 */
        klSelect: () => tone(560, 0.04, 'square', 0.07),
        /** 无法移动：低频闷响（撞墙/卡死反馈） */
        klBlock: () => tone(110, 0.09, 'square', 0.13, 70),
        /** 撤销：两段下滑回溯音 */
        klUndo: () => { tone(420, 0.05, 'triangle', 0.09); tone(300, 0.07, 'triangle', 0.09, 0, 0.05); },
        /** 求助提示：轻快三连上行"叮叮叮"（金点子闪现的灵感音，H 键提示） */
        klHint: () => { tone(660, 0.05, 'triangle', 0.09); tone(880, 0.05, 'triangle', 0.09, 0, 0.06); tone(1320, 0.12, 'triangle', 0.1, 0, 0.12); },
        /** 通关：胜利六连琶音 */
        klWin: () => arpeggio([523, 659, 784, 1047, 1319, 1568], 0.09, 'square', 0.13),
        /** S 级评级专属：明亮大调琶音 + 高音 sparkle 长尾（结算面板揭晓 S 级的仪式感） */
        klRankS: () => {
            arpeggio([523, 659, 784, 1047], 0.08, 'triangle', 0.11);
            tone(1568, 0.35, 'triangle', 0.08, 0, 0.36); // 高音 sparkle 长尾
            tone(2093, 0.3, 'sine', 0.05, 0, 0.44);
        },
        /** 曹操滑动专属：低音区厚重滑音 + 摩擦噪声（一代枭雄的分量感，与普通棋子的轻快滑音区分） */
        klMoveCao: (steps = 1) => {
            const f = 140 + (Math.max(1, steps) - 1) * 40; // 低音区随步数微升，但整体保持厚重
            tone(f, 0.11, 'square', 0.12, f * 0.65);
            noise(0.06, 0.05, 500);
        },
        /** 选中曹操专属：庄重低音双响（"枭雄登场"的低频分量，与普通棋子的轻点音区分） */
        klSelectCao: () => { tone(196, 0.07, 'triangle', 0.11); tone(294, 0.09, 'triangle', 0.09, 0, 0.06); },
        /** 曹操破门逃脱：低频上滑轰鸣 + 摩擦噪声 + 高音闪（逃脱演出起手的破门冲刺质感） */
        klEscape: () => {
            tone(80, 0.55, 'sawtooth', 0.13, 300); // 低频上滑：破门瞬间的轰鸣推升
            noise(0.25, 0.07, 600); // 摩擦噪声：木屑纷飞的粗粝感
            tone(1200, 0.2, 'sine', 0.06, 1800, 0.3); // 延迟高音闪：冲出后的余韵
        },
        /** 开局开演：古风号角三连音（延迟起奏，与通用 start 琶音错峰） */
        klGo: () => [392, 523, 784].forEach((f, i) => tone(f, 0.12, 'triangle', 0.12, 0, 0.25 + i * 0.1)),
        /** 布局切换：木质翻牌摩擦双音（换局时的道具翻动质感） */
        klLayout: () => { tone(440, 0.07, 'triangle', 0.1, 300); noise(0.05, 0.04, 800); },
        /** 连击里程碑：音高随档位递增的双音（妙手连击的爽快感；档位封顶封底防非法下标取 undefined） */
        klCombo: (lvl = 0) => { const f = [660, 784, 988][Math.max(0, Math.min(lvl, 2))]; tone(f, 0.06, 'square', 0.11); tone(f * 1.5, 0.1, 'square', 0.1, 0, 0.05); },
        /** 逼近纪录：低音心跳两连（破纪录前的紧张感） */
        klTense: () => { tone(92, 0.1, 'sine', 0.13); tone(92, 0.12, 'sine', 0.13, 0, 0.16); },
    });
})();
